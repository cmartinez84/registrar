--
-- Database: `registrar`
--
CREATE DATABASE IF NOT EXISTS `registrar` DEFAULT CHARACTER SET utf8 COLLATE utf8_general_ci;
USE `registrar`;

-- --------------------------------------------------------

--
-- Table structure for table `courses`
--

CREATE TABLE `courses` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `course_number` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `courses`
--

INSERT INTO `courses` (`id`, `name`, `course_number`) VALUES
(2, 'Intro to Anthropology', 'Anth 101'),
(3, 'Econ', 'Ec101'),
(5, 'Econ', 'Ec101'),
(6, 'hippes', '909090'),
(7, 'Under water basket weaving ', 'UWB101'),
(8, 'Under water basket weaving ', 'UWB101'),
(9, 'Under water basket weaving ', 'UWB101'),
(10, 'Under water basket weaving ', 'UWB101'),
(11, '', ''),
(12, '', ''),
(13, '', ''),
(14, 'hi', 'world'),
(15, 'hi', 'world'),
(16, 'hi', 'world'),
(17, 'boy', ' bye');

-- --------------------------------------------------------

--
-- Table structure for table `courses_departments`
--

CREATE TABLE `courses_departments` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `course_id` int(11) DEFAULT NULL,
  `department_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `departments`
--

CREATE TABLE `departments` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `students`
--

CREATE TABLE `students` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `enrollment` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `students`
--

INSERT INTO `students` (`id`, `name`, `enrollment`) VALUES
(8, 'burger', '2016-09-07'),
(9, 'Susan', '2016-09-15'),
(10, 'Bob', '2016-09-10'),
(11, 'Sally', '2016-09-15'),
(12, 'Sally', '2016-09-15'),
(13, 'Linda', '2016-09-15'),
(14, 'Louise', '2016-09-14'),
(15, 'Tina', '2016-09-21'),
(16, 'Gene', '2016-09-15'),
(17, 'Teddy', '2016-09-16'),
(18, 'Mort', '2016-09-23'),
(22, 'Bart Sampson', '2016-09-30'),
(23, 'Marge Simpsons', '2016-09-23'),
(24, 'Chris', '2016-09-23'),
(25, 'Jesus', '0001-02-21');

-- --------------------------------------------------------

--
-- Table structure for table `students_courses`
--

CREATE TABLE `students_courses` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `course_id` int(11) DEFAULT NULL,
  `student_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `students_courses`
--

INSERT INTO `students_courses` (`id`, `course_id`, `student_id`) VALUES
(4, 6, 20),
(5, 2, 21),
(8, 6, 8),
(9, 6, 13),
(11, 6, 10),
(12, 6, 9),
(13, 6, 12),
(14, 6, 13),
(15, 6, 14),
(16, 6, 12),
(17, 6, 13),
(18, 6, 14),
(19, 6, 9),
(20, 5, 8),
(21, 5, 9),
(22, 5, 10),
(23, 5, 11),
(24, 5, 13),
(25, 5, 14),
(26, 5, 12),
(27, 5, 15),
(28, 5, 16),
(29, 5, 17),
(31, 6, 22),
(32, 6, 23),
(33, 6, 11),
(34, 6, 15),
(35, 6, 16),
(36, 6, 17),
(37, 6, 19),
(50, 3, 8),
(51, 3, 9),
(52, 3, 10),
(53, 3, 11),
(54, 3, 12),
(55, 3, 13),
(56, 3, 14),
(57, 3, 15),
(58, 3, 16),
(59, 3, 17),
(61, 3, 19),
(62, 3, 22),
(63, 3, 23),
(78, 3, 18),
(79, 3, 18),
(83, 2, 8),
(84, 2, 9),
(85, 2, 10),
(86, 2, 11),
(87, 2, 12),
(88, 2, 13),
(89, 2, 14),
(90, 2, 15),
(91, 2, 16),
(92, 2, 17),
(93, 2, 18),
(94, 2, 19),
(95, 2, 22),
(96, 2, 23),
(97, 2, 24),
(98, 6, 8),
(100, 1, 13),
(101, 1, 10);

-- --------------------------------------------------------

--
-- Table structure for table `students_departments`
--

CREATE TABLE `students_departments` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `student_id` int(11) DEFAULT NULL,
  `department_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `courses`
--
ALTER TABLE `courses`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `id` (`id`);

--
-- Indexes for table `courses_departments`
--
ALTER TABLE `courses_departments`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `id` (`id`);

--
-- Indexes for table `departments`
--
ALTER TABLE `departments`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `id` (`id`);

--
-- Indexes for table `students`
--
ALTER TABLE `students`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `id` (`id`);

--
-- Indexes for table `students_courses`
--
ALTER TABLE `students_courses`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `id` (`id`);

--
-- Indexes for table `students_departments`
--
ALTER TABLE `students_departments`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `id` (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `courses`
--
ALTER TABLE `courses`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;
--
-- AUTO_INCREMENT for table `courses_departments`
--
ALTER TABLE `courses_departments`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `departments`
--
ALTER TABLE `departments`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `students`
--
ALTER TABLE `students`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=26;
--
-- AUTO_INCREMENT for table `students_courses`
--
ALTER TABLE `students_courses`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=102;
--
-- AUTO_INCREMENT for table `students_departments`
--
ALTER TABLE `students_departments`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
